document.addEventListener("DOMContentLoaded", () => {
    const weatherButton = document.getElementById("weatherImg");
    const weatherText = document.getElementById("weatherText");
    const realWeatherButton = document.getElementById("realWeatherButton");

    const API_URL = "https://api.open-meteo.com/v1/forecast";

    function getLocationAndWeather() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                fetchWeather(latitude, longitude);
            }, () => {
                weatherText.innerText = "Could not access location. Try again.";
            });
        } else {
            weatherText.innerText = "Geolocation is not supported by this browser.";
        }
    }

    function fetchWeather(lat, lon) {
        fetch(`${API_URL}?latitude=${lat}&longitude=${lon}&hourly=temperature_2m,weathercode&past_days=1`)
            .then(response => response.json())
            .then(data => {
                const pastWeatherIndex = data.hourly.weathercode.length - 2; 
                const pastWeatherCode = data.hourly.weathercode[pastWeatherIndex];

                const weatherMap = {
                    0: "sunny",
                    1: "sunny",
                    2: "cloudy",
                    3: "cloudy",
                    45: "foggy",
                    48: "foggy",
                    51: "rain",
                    53: "rain",
                    55: "rain",
                    61: "rain",
                    63: "rain",
                    65: "rain",
                    66: "rain",
                    67: "rain",
                    71: "snow",
                    73: "snow",
                    75: "snow",
                    77: "snow",
                    80: "rain",
                    81: "rain",
                    82: "rain",
                    85: "snow",
                    86: "snow",
                    95: "storm",
                    96: "storm",
                    99: "storm"
                };

                let pastWeather = weatherMap[pastWeatherCode] || "unknown";
                let oppositeWeather = {
                    "rain": "sunny.png",
                    "sunny": "rain.png",
                    "snow": "windy.png",
                    "windy": "snow.png",
                    "cloudy": "sunny.png",
                    "foggy": "windy.png",
                    "storm": "snow.png"
                }[pastWeather] || "default.png";

                weatherText.innerText = `One hour ago: ${pastWeather.toUpperCase()}.`;
                document.body.style.backgroundImage = `url('static/${oppositeWeather}')`;

                weatherButton.src = "static/weather_button_pressed.png";
            });
    }

    weatherButton.addEventListener("click", getLocationAndWeather);
    realWeatherButton.addEventListener("click", () => alert("Go outside for once."));
});
